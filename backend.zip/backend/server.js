import express from "express";
import cors from "cors";
import productsRouter from "./routes.js";
import fs from "fs";

const app = express();
app.use(cors());
app.use(express.json());

// Asegura que database.json exista
if (!fs.existsSync("database.json")) {
  fs.writeFileSync("database.json", JSON.stringify({ products: [] }, null, 2));
}

app.use("/", productsRouter);

app.listen(3000, () => console.log("Backend listo en http://localhost:3000"));
