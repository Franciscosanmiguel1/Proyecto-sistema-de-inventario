import React, { useContext, useEffect, useState } from 'react';
import api from '../services/api';
import { AppContext } from '../context/AppContext';
import ProductList from '../components/productlist';

export default function ProductosPage() {
  const { state, dispatch } = useContext(AppContext);
  const [form, setForm] = useState({ nombre: '', stock: '', precio: '' });

  useEffect(() => {
    async function fetchProductos() {
      dispatch({ type: 'FETCH_START' });
      try {
        const res = await api.get('/productos');
        dispatch({ type: 'FETCH_SUCCESS', payload: res.data });
      } catch (err) {
        dispatch({ type: 'FETCH_ERROR', payload: err.message || 'Error' });
      }
    }
    fetchProductos();
  }, [dispatch]);

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    // validación mínima
    if (!form.nombre || !form.stock) return alert('Nombre y stock requeridos');
    try {
      const payload = { nombre: form.nombre, stock: Number(form.stock), precio: Number(form.precio || 0) };
      const res = await api.post('/productos', payload);
      dispatch({ type: 'ADD_PRODUCT', payload: res.data });
      setForm({ nombre: '', stock: '', precio: '' });
    } catch (err) {
      alert('Error al crear producto: ' + (err.message || ''));
    }
  };

  return (
    <div>
      <h2>Productos</h2>

      {state.loading && <p>Cargando productos...</p>}
      {state.error && <p style={{ color: 'red' }}>Error: {state.error}</p>}

      <ProductList productos={state.productos} />

      <hr />

      <h3>Agregar producto</h3>
      <form onSubmit={handleSubmit} style={{ maxWidth: 360 }}>
        <div style={{ marginBottom: 8 }}>
          <label>Nombre</label><br />
          <input name="nombre" value={form.nombre} onChange={handleChange} />
        </div>
        <div style={{ marginBottom: 8 }}>
          <label>Stock</label><br />
          <input name="stock" value={form.stock} onChange={handleChange} type="number" />
        </div>
        <div style={{ marginBottom: 8 }}>
          <label>Precio</label><br />
          <input name="precio" value={form.precio} onChange={handleChange} type="number" step="0.01" />
        </div>
        <button type="submit">Agregar</button>
      </form>
    </div>
  );
}
