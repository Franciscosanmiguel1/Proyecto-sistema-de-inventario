import React from 'react';

export default function ProductList({ productos }) {
  if (!productos || productos.length === 0) return <p>No hay productos.</p>;
  return (
    <ul>
      {productos.map(p => (
        <li key={p.id}>
          <strong>{p.nombre}</strong> — Stock: {p.stock} — ${p.precio}
        </li>
      ))}
    </ul>
  );
}
